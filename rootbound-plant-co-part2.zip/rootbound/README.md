# Rootbound Plant Co.

Independent plant shop website (Johannesburg) — WEDE5020 POE. **Part 2: CSS styling and responsive design.**

## Pages
`index.html` · `shop.html` · `care-guides.html` · `about.html` · `delivery.html` · `cart.html`
All six pages link to one external stylesheet: `styles.css` (and `script.js` for the menu toggle, filters and cart badge).

## Project structure
```
rootbound/
├── index.html, shop.html, care-guides.html, about.html, delivery.html, cart.html
├── styles.css        single external stylesheet
├── script.js
├── images/           responsive images (JPG + WebP, several widths)
├── screenshots/      device evidence for Section 3.4
└── README.md
```

## CSS approach (Part 2)

**Naming/organisation.** `styles.css` is split into numbered sections: 1 Reset, 2 Tokens, 3 Base & typography, 4 Layout, 5 Components, 6 Interactive states, 7 Responsive. Class names are lowercase and hyphenated (`.product-card`, `.filter-bar`, `.nav-toggle`).

**Base style and reset.** A small reset (box-sizing, zeroed margins, fluid images, inherited form fonts) sits at the top. Defaults are set once on `body` (Inter, 1rem, 1.6 line-height, cream background, ink text). Colours, radius, shadows and spacing are CSS custom properties in `:root`, so the whole colour scheme can be changed in one place.

**Typography.** Fraunces for headings, Inter for body text. Sizes come from a 1.25-ratio scale (`--step--1` … `--step-5`) in `rem`. Headings use tight `line-height` and slight negative `letter-spacing`; body text uses `line-height: 1.6` and `max-width: 60ch` for readable line length. Heading sizes step up at the tablet and desktop breakpoints.

**Layout.** Flexbox for the header, nav, filter bar, footer and product card internals. CSS Grid for the hero, product grid, article grid, delivery cards and the desktop newsletter block. `.wrap` centres content at `72rem`.

**Visual styles.** `color`, `background-color`, `border`, `border-radius` and `box-shadow` define cards, buttons and badges. Interactive pseudo-classes: `:hover` (links, buttons, cards lift with a shadow), `:focus-visible` (visible 3px outline for keyboard users), `:active` (buttons press down), `:focus` on the newsletter input.

**Cascading with few selectors.** Shared rules are grouped (e.g. `.product-card, .article-card, .info-card` share one border/radius/background rule). Inline styles that Part 1 had on the nav, footer and sections were removed so every style lives in the stylesheet.

## Responsive design

Mobile-first: base styles are for phones; `min-width` media queries add layout for larger screens. Breakpoints are written in `em` so they respect the user's font size.

| Breakpoint | Device | Layout |
|---|---|---|
| base (< 48em / 768px) | Mobile | Single column; hamburger menu; 2-column product grid; stacked hero, newsletter and footer |
| `min-width: 48em` (768px) | Tablet | Inline nav (menu button hidden); 2-column hero, articles and delivery cards; 3-column products |
| `min-width: 64em` (1024px) | Desktop | 4-column products and delivery cards; wider spacing; side-by-side newsletter; footer in one row |
| `max-width: 30em` (480px) | Small phones | Tighter gaps; full-width hero buttons |

**Relative units.** `rem` for font sizes, spacing, radii and breakpoints; `em` in media queries; `%`/`fr` and `width: 100%` for containers, grids, tables and images (`max-width: 100%; height: auto` on all images).

**Responsive images.**
- Products and care-guide covers use `srcset` with `w` descriptors plus `sizes`, so the browser picks 400w or 800w (480w/960w for guides) based on the layout width.
- The home hero uses `<picture>`: a portrait crop for screens up to 37.5em and a landscape image (800/1200/1800w, WebP with JPG fallback) for larger screens.
- Below-the-fold images use `loading="lazy"`; all images have `width`/`height` (prevents layout shift) and descriptive `alt` text.
- Image files are illustrations created for this project.

## Testing across screen sizes (Section 3.4)

Tested with browser developer tools (device emulation) at the sizes below. No horizontal scrolling at any size.

| Device | Viewport | Home | Shop |
|---|---|---|---|
| Desktop | 1440 × 900 | `screenshots/index-desktop-1440x900.png` | `screenshots/shop-desktop-1440x900.png` |
| Laptop | 1024 × 768 | `screenshots/index-laptop-1024x768.png` | `screenshots/shop-laptop-1024x768.png` |
| Tablet (iPad) | 768 × 1024 | `screenshots/index-tablet-ipad-768x1024.png` | `screenshots/shop-tablet-ipad-768x1024.png` |
| Mobile (iPhone SE) | 375 × 667 | `screenshots/index-mobile-iphone-se-375x667.png` | `screenshots/shop-mobile-iphone-se-375x667.png` |
| Mobile (Galaxy S20) | 360 × 800 | `screenshots/index-mobile-galaxy-s20-360x800.png` | `screenshots/shop-mobile-galaxy-s20-360x800.png` |

## Changelog

### Part 2 — CSS styling & responsive design
- **Stylesheet:** rewrote `styles.css` into numbered sections with a CSS reset, design tokens, a rem-based type scale, and separate tablet and desktop breakpoints (Part 1 only had one mobile-first set of rules with a single desktop tweak at 780px).
- **Desktop layout:** header, hero (5fr/6fr grid), 4-column product grid, 4-column delivery cards, side-by-side newsletter and single-row footer added.
- **Header/nav (all pages):** removed the `.header-row` wrapper and the inline-styled `.wrap` div inside `<nav>`; header is now one flex container, inline nav from 768px, hamburger below.
- **Inline styles removed (all pages):** footer `<strong style>`, about-page section `style`, and `style="margin-top:20px"` paragraphs replaced with the `.section-cta` class.
- **Images:** replaced the CSS-gradient placeholders (`.hero-visual`, `.product-photo`, `.article-photo`) with real `<img>`/`<picture>` elements using `srcset`, `sizes`, WebP + JPG, lazy loading and alt text.
- **Accessibility/contrast:** primary buttons and newsletter button now use `--terracotta-deep`, and the newsletter panel and active filter pill use `--sage-deep`, so white/cream text has stronger contrast; added `:focus-visible` outlines and a `prefers-reduced-motion` rule.
- **Interactive states:** added hover, focus and active styles for links, nav, buttons, filter pills, cards and the newsletter input.

### Part 1 feedback corrections
<!-- ADD ONE ENTRY PER FEEDBACK POINT from your Part 1 marks sheet, in this format:
- **[page/file] — feedback:** "<what the lecturer said>" → **change:** <what you changed and why> -->
_Not yet completed — add each item from the Part 1 feedback here, with a detailed description of the edit._
