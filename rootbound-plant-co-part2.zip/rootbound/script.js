// Rootbound Plant Co. — small shared behaviours

document.addEventListener("DOMContentLoaded", function () {
  var toggle = document.querySelector(".nav-toggle");
  var nav = document.querySelector(".site-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var isOpen = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
    });
  }

  // Filter buttons on shop page (visual only — demonstrates the UX pattern)
  var filterButtons = document.querySelectorAll(".filter-bar button");
  var cards = document.querySelectorAll(".product-card");
  filterButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      filterButtons.forEach(function (b) { b.classList.remove("active"); });
      btn.classList.add("active");
      var filter = btn.dataset.filter;
      cards.forEach(function (card) {
        if (filter === "all" || card.dataset.tags.indexOf(filter) !== -1) {
          card.style.display = "";
        } else {
          card.style.display = "none";
        }
      });
    });
  });

  // Cart badge count, persisted only for this session via a simple counter
  var badge = document.querySelector(".cart-badge");
  var addButtons = document.querySelectorAll(".add-btn");
  var count = 0;
  addButtons.forEach(function (btn) {
    btn.addEventListener("click", function () {
      count++;
      if (badge) badge.textContent = count;
      var original = btn.textContent;
      btn.textContent = "Added";
      setTimeout(function () { btn.textContent = original; }, 900);
    });
  });

  // Newsletter form
  var newsletterForm = document.querySelector(".newsletter form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      var btn = newsletterForm.querySelector("button");
      btn.textContent = "Subscribed";
    });
  }
});
